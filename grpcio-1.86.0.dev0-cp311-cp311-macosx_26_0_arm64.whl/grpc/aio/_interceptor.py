# Copyright 2019 gRPC authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Interceptors implementation of gRPC Asyncio Python."""
# This file has multiple pyright errors reported related to reportPrivateUsage
# hence suppressing it at file level. https://github.com/grpc/grpc/pull/42743
# pyright: reportPrivateUsage = false

from __future__ import annotations

from abc import ABCMeta
from abc import abstractmethod
import asyncio
import functools
from typing import (
    Any,
    AsyncIterable,
    AsyncIterator,
    Awaitable,
    Callable,
    Generator,
    Generic,
    List,
    MutableSequence,
    NamedTuple,
    Optional,
    Protocol,
    Sequence,
    Union,
)

import grpc
from grpc._cython import cygrpc
from typing_extensions import TypeIs

from . import _base_call
from ._call import AioRpcError
from ._call import StreamStreamCall
from ._call import StreamUnaryCall
from ._call import UnaryStreamCall
from ._call import UnaryUnaryCall
from ._call import _API_STYLE_ERROR
from ._call import _RPC_ALREADY_FINISHED_DETAILS
from ._call import _RPC_HALF_CLOSED_DETAILS
from ._metadata import Metadata
from ._typing import DeserializingFunction
from ._typing import DoneCallbackType
from ._typing import EOFType
from ._typing import RequestIterableType
from ._typing import RequestType
from ._typing import ResponseIterableType
from ._typing import ResponseType
from ._typing import SerializingFunction
from ._utils import _timeout_to_deadline

_LOCAL_CANCELLATION_DETAILS = "Locally cancelled by application!"


class _FinishIteratorSentinel:
    pass


_FINISH_ITERATOR_SENTINEL = _FinishIteratorSentinel()


class ServerInterceptor(metaclass=ABCMeta):
    """Affords intercepting incoming RPCs on the service-side.

    This is an EXPERIMENTAL API.
    """

    @abstractmethod
    async def intercept_service(
        self,
        continuation: Callable[
            [grpc.HandlerCallDetails], Awaitable[grpc.RpcMethodHandler]
        ],
        handler_call_details: grpc.HandlerCallDetails,
    ) -> grpc.RpcMethodHandler:
        """Intercepts incoming RPCs before handing them over to a handler.

        State can be passed from an interceptor to downstream interceptors
        via contextvars. The first interceptor is called from an empty
        contextvars.Context, and the same Context is used for downstream
        interceptors and for the final handler call. Note that there are no
        guarantees that interceptors and handlers will be called from the
        same thread.

        Args:
            continuation: A function that takes a HandlerCallDetails and
                proceeds to invoke the next interceptor in the chain, if any,
                or the RPC handler lookup logic, with the call details passed
                as an argument, and returns an RpcMethodHandler instance if
                the RPC is considered serviced, or None otherwise.
            handler_call_details: A HandlerCallDetails describing the RPC.

        Returns:
            An RpcMethodHandler with which the RPC may be serviced if the
            interceptor chooses to service this RPC, or None otherwise.
        """


class ClientCallDetails(
    NamedTuple(
        "_ClientCallDetails",
        [
            ("method", bytes),
            ("timeout", Optional[float]),
            ("metadata", Optional[Metadata]),
            ("credentials", Optional[grpc.CallCredentials]),
            ("wait_for_ready", Optional[bool]),
        ],
    ),
    grpc.ClientCallDetails,
):
    """Describes an RPC to be invoked.

    This is an EXPERIMENTAL API.

    Args:
        method: The method name of the RPC.
        timeout: An optional duration of time in seconds to allow for the RPC.
        metadata: Optional metadata to be transmitted to the service-side of
          the RPC.
        credentials: An optional CallCredentials for the RPC.
        wait_for_ready: An optional flag to enable :term:`wait_for_ready` mechanism.
    """


class ClientInterceptor(metaclass=ABCMeta):
    """Base class used for all Aio Client Interceptor classes"""


class UnaryUnaryClientInterceptor(ClientInterceptor, metaclass=ABCMeta):
    """Affords intercepting unary-unary invocations."""

    @abstractmethod
    async def intercept_unary_unary(
        self,
        continuation: Callable[
            [ClientCallDetails, RequestType],
            Awaitable[_base_call.UnaryUnaryCall[RequestType, ResponseType]],
        ],
        client_call_details: ClientCallDetails,
        request: RequestType,
    ) -> Union[
        _base_call.UnaryUnaryCall[RequestType, ResponseType], ResponseType
    ]:
        """Intercepts a unary-unary invocation asynchronously.

        Args:
          continuation: A coroutine that proceeds with the invocation by
            executing the next interceptor in the chain or invoking the
            actual RPC on the underlying Channel. It is the interceptor's
            responsibility to call it if it decides to move the RPC forward.
            The interceptor can use
            `call = await continuation(client_call_details, request)`
            to continue with the RPC. `continuation` returns the call to the
            RPC.
          client_call_details: A ClientCallDetails object describing the
            outgoing RPC.
          request: The request value for the RPC.

        Returns:
          An object with the RPC response.

        Raises:
          AioRpcError: Indicating that the RPC terminated with non-OK status.
          asyncio.CancelledError: Indicating that the RPC was canceled.
        """


class UnaryStreamClientInterceptor(ClientInterceptor, metaclass=ABCMeta):
    """Affords intercepting unary-stream invocations."""

    @abstractmethod
    async def intercept_unary_stream(
        self,
        continuation: Callable[
            [ClientCallDetails, RequestType],
            Awaitable[_base_call.UnaryStreamCall[RequestType, ResponseType]],
        ],
        client_call_details: ClientCallDetails,
        request: RequestType,
    ) -> Union[
        ResponseIterableType[ResponseType],
        _base_call.UnaryStreamCall[RequestType, ResponseType],
    ]:
        """Intercepts a unary-stream invocation asynchronously.

        The function could return the call object or an asynchronous
        iterator, in case of being an asyncrhonous iterator this will
        become the source of the reads done by the caller.

        Args:
          continuation: A coroutine that proceeds with the invocation by
            executing the next interceptor in the chain or invoking the
            actual RPC on the underlying Channel. It is the interceptor's
            responsibility to call it if it decides to move the RPC forward.
            The interceptor can use
            `call = await continuation(client_call_details, request)`
            to continue with the RPC. `continuation` returns the call to the
            RPC.
          client_call_details: A ClientCallDetails object describing the
            outgoing RPC.
          request: The request value for the RPC.

        Returns:
          The RPC Call or an asynchronous iterator.

        Raises:
          AioRpcError: Indicating that the RPC terminated with non-OK status.
          asyncio.CancelledError: Indicating that the RPC was canceled.
        """


class StreamUnaryClientInterceptor(ClientInterceptor, metaclass=ABCMeta):
    """Affords intercepting stream-unary invocations."""

    @abstractmethod
    async def intercept_stream_unary(
        self,
        continuation: Callable[
            [ClientCallDetails, RequestIterableType[RequestType]],
            Awaitable[_base_call.StreamUnaryCall[RequestType, ResponseType]],
        ],
        client_call_details: ClientCallDetails,
        request_iterator: RequestIterableType[RequestType],
    ) -> _base_call.StreamUnaryCall[RequestType, ResponseType]:
        """Intercepts a stream-unary invocation asynchronously.

        Within the interceptor the usage of the call methods like `write` or
        even awaiting the call should be done carefully, since the caller
        could be expecting an untouched call, for example for start writing
        messages to it.

        Args:
          continuation: A coroutine that proceeds with the invocation by
            executing the next interceptor in the chain or invoking the
            actual RPC on the underlying Channel. It is the interceptor's
            responsibility to call it if it decides to move the RPC forward.
            The interceptor can use
            `call = await continuation(client_call_details, request_iterator)`
            to continue with the RPC. `continuation` returns the call to the
            RPC.
          client_call_details: A ClientCallDetails object describing the
            outgoing RPC.
          request_iterator: The request iterator that will produce requests
            for the RPC.

        Returns:
          The RPC Call.

        Raises:
          AioRpcError: Indicating that the RPC terminated with non-OK status.
          asyncio.CancelledError: Indicating that the RPC was canceled.
        """


class StreamStreamClientInterceptor(ClientInterceptor, metaclass=ABCMeta):
    """Affords intercepting stream-stream invocations."""

    @abstractmethod
    async def intercept_stream_stream(
        self,
        continuation: Callable[
            [ClientCallDetails, RequestIterableType[RequestType]],
            Awaitable[_base_call.StreamStreamCall[RequestType, ResponseType]],
        ],
        client_call_details: ClientCallDetails,
        request_iterator: RequestIterableType[RequestType],
    ) -> Union[
        ResponseIterableType[ResponseType],
        _base_call.StreamStreamCall[RequestType, ResponseType],
    ]:
        """Intercepts a stream-stream invocation asynchronously.

        Within the interceptor the usage of the call methods like `write` or
        even awaiting the call should be done carefully, since the caller
        could be expecting an untouched call, for example for start writing
        messages to it.

        The function could return the call object or an asynchronous
        iterator, in case of being an asyncrhonous iterator this will
        become the source of the reads done by the caller.

        Args:
          continuation: A coroutine that proceeds with the invocation by
            executing the next interceptor in the chain or invoking the
            actual RPC on the underlying Channel. It is the interceptor's
            responsibility to call it if it decides to move the RPC forward.
            The interceptor can use
            `call = await continuation(client_call_details, request_iterator)`
            to continue with the RPC. `continuation` returns the call to the
            RPC.
          client_call_details: A ClientCallDetails object describing the
            outgoing RPC.
          request_iterator: The request iterator that will produce requests
            for the RPC.

        Returns:
          The RPC Call or an asynchronous iterator.

        Raises:
          AioRpcError: Indicating that the RPC terminated with non-OK status.
          asyncio.CancelledError: Indicating that the RPC was canceled.
        """


class InterceptedCall:
    """Base implementation for all intercepted call arities.

    Interceptors might have some work to do before the RPC invocation with
    the capacity of changing the invocation parameters, and some work to do
    after the RPC invocation with the capacity for accessing to the wrapped
    `UnaryUnaryCall`.

    It handles also early and later cancellations, when the RPC has not even
    started and the execution is still held by the interceptors or when the
    RPC has finished but again the execution is still held by the interceptors.

    Once the RPC is finally executed, all methods are finally done against the
    intercepted call, being at the same time the same call returned to the
    interceptors.

    As a base class for all of the interceptors implements the logic around
    final status, metadata and cancellation.
    """

    _interceptors_task: asyncio.Task[_base_call.Call]
    _pending_add_done_callbacks: MutableSequence[DoneCallbackType]

    def __init__(
        self, interceptors_task: asyncio.Task[_base_call.Call]
    ) -> None:
        self._interceptors_task = interceptors_task
        self._pending_add_done_callbacks = []
        self._interceptors_task.add_done_callback(
            self._fire_or_add_pending_done_callbacks
        )

    def __del__(self):
        self.cancel()

    def _fire_or_add_pending_done_callbacks(
        self, interceptors_task: asyncio.Task[_base_call.Call]
    ) -> None:
        if not self._pending_add_done_callbacks:
            return

        call_completed = False

        call = None
        if interceptors_task.cancelled() or (
            interceptors_task.done()
            and interceptors_task.exception() is not None
        ):
            call_completed = True
        else:
            call = interceptors_task.result()
            if call.done():
                call_completed = True

        if call_completed:
            for callback in self._pending_add_done_callbacks:
                callback(self)
        elif call is not None:
            for callback in self._pending_add_done_callbacks:
                callback = functools.partial(
                    self._wrap_add_done_callback, callback
                )
                call.add_done_callback(callback)
        else:
            err_msg = "Call not available"
            raise RuntimeError(err_msg)

        self._pending_add_done_callbacks = []

    def _wrap_add_done_callback(
        self, callback: DoneCallbackType, unused_call: _base_call.Call
    ) -> None:
        callback(self)

    def cancel(self) -> bool:
        if self._interceptors_task.cancelled():
            return False

        if not self._interceptors_task.done():
            # There is no yet the intercepted call available,
            # Trying to cancel it by using the generic Asyncio
            # cancellation method.
            return self._interceptors_task.cancel()

        if self._interceptors_task.exception() is not None:
            return False

        call = self._interceptors_task.result()

        return call.cancel()

    def cancelled(self) -> bool:
        if self._interceptors_task.cancelled():
            return True
        if not self._interceptors_task.done():
            return False

        exc = self._interceptors_task.exception()
        if exc is not None:
            if isinstance(exc, AioRpcError):
                return exc.code() == grpc.StatusCode.CANCELLED
            return False

        call = self._interceptors_task.result()

        return call.cancelled()

    def done(self) -> bool:
        if self._interceptors_task.cancelled():
            return True
        if not self._interceptors_task.done():
            return False
        if self._interceptors_task.exception() is not None:
            return True

        call = self._interceptors_task.result()

        return call.done()

    def add_done_callback(self, callback: DoneCallbackType) -> None:
        if not self._interceptors_task.done():
            self._pending_add_done_callbacks.append(callback)
            return

        if (
            self._interceptors_task.cancelled()
            or self._interceptors_task.exception() is not None
        ):
            callback(self)
            return

        call = self._interceptors_task.result()

        if call.done():
            callback(self)
        else:
            callback = functools.partial(self._wrap_add_done_callback, callback)
            call.add_done_callback(callback)

    def time_remaining(self) -> Optional[float]:
        raise NotImplementedError()

    async def initial_metadata(self) -> Metadata:
        try:
            call = await self._interceptors_task
        except AioRpcError as err:
            md = err.initial_metadata()
            return md if md is not None else Metadata()
        except asyncio.CancelledError:
            return Metadata()

        return await call.initial_metadata()

    async def trailing_metadata(self) -> Metadata:
        try:
            call = await self._interceptors_task
        except AioRpcError as err:
            md = err.trailing_metadata()
            return md if md is not None else Metadata()
        except asyncio.CancelledError:
            return Metadata()

        return await call.trailing_metadata()

    async def code(self) -> grpc.StatusCode:
        try:
            call = await self._interceptors_task
        except AioRpcError as err:
            return err.code()
        except asyncio.CancelledError:
            return grpc.StatusCode.CANCELLED

        return await call.code()

    async def details(self) -> str:
        try:
            call = await self._interceptors_task
        except AioRpcError as err:
            return err.details() or ""
        except asyncio.CancelledError:
            return _LOCAL_CANCELLATION_DETAILS

        return await call.details()

    async def debug_error_string(self) -> Optional[str]:
        try:
            call = await self._interceptors_task
        except AioRpcError as err:
            return err.debug_error_string()
        except asyncio.CancelledError:
            return ""
        # debug_error_string is implemented on concrete calls but not yet
        # declared on _base_call.Call. We suppress pyright[reportAttributeAccessIssue]
        # to avoid public API changes for now.
        return await call.debug_error_string()  # type: ignore[reportAttributeAccessIssue]

    async def wait_for_connection(self) -> None:
        call = await self._interceptors_task
        return await call.wait_for_connection()


class _InterceptedResponseMixinProtocol(Protocol):
    _interceptors_task: asyncio.Task[Any]


class _InterceptedUnaryResponseMixin(
    _InterceptedResponseMixinProtocol, Generic[ResponseType]
):

    def __await__(self) -> Generator[Any, None, ResponseType]:
        call: Awaitable[ResponseType] = (
            yield from self._interceptors_task.__await__()
        )
        response: ResponseType = yield from call.__await__()
        return response


class _InterceptedStreamResponseMixin(
    _InterceptedResponseMixinProtocol, Generic[ResponseType]
):
    _response_aiter: Optional[AsyncIterator[ResponseType]]

    def _init_stream_response_mixin(self) -> None:
        # Is initialized later, otherwise if the iterator is not finally
        # consumed a logging warning is emitted by Asyncio.
        self._response_aiter = None

    async def _wait_for_interceptor_task_response_iterator(
        self,
    ) -> AsyncIterator[ResponseType]:
        call = await self._interceptors_task
        async for response in call:
            yield response

    def __aiter__(self) -> AsyncIterator[ResponseType]:
        if self._response_aiter is None:
            self._response_aiter = (
                self._wait_for_interceptor_task_response_iterator()
            )
        return self._response_aiter

    async def read(self) -> Union[EOFType, ResponseType]:
        if self._response_aiter is None:
            self._response_aiter = (
                self._wait_for_interceptor_task_response_iterator()
            )
        return await anext(self._response_aiter, cygrpc.EOF)


class _InterceptedStreamRequestMixinProtocol(Protocol):
    _interceptors_task: asyncio.Task[Any]
    _loop: asyncio.AbstractEventLoop


class _InterceptedStreamRequestMixin(
    _InterceptedStreamRequestMixinProtocol, Generic[RequestType]
):
    _write_to_iterator_async_gen: Optional[AsyncIterable[RequestType]]
    _write_to_iterator_queue: Optional[
        asyncio.Queue[Union[RequestType, _FinishIteratorSentinel]]
    ]
    _status_code_task: Optional[asyncio.Task[grpc.StatusCode]]

    def _init_stream_request_mixin(
        self, request_iterator: Optional[RequestIterableType[RequestType]]
    ) -> RequestIterableType[RequestType]:
        if request_iterator is None:
            # We provide our own request iterator which is a proxy
            # of the futures writes that will be done by the caller.
            self._write_to_iterator_queue = asyncio.Queue(maxsize=1)
            self._write_to_iterator_async_gen = (
                self._proxy_writes_as_request_iterator()
            )
            self._status_code_task = None
            request_iterator = self._write_to_iterator_async_gen
        else:
            self._write_to_iterator_queue = None

        return request_iterator

    async def _proxy_writes_as_request_iterator(
        self,
    ) -> AsyncIterator[RequestType]:
        await self._interceptors_task

        if self._write_to_iterator_queue is None:
            raise cygrpc.UsageError(_API_STYLE_ERROR)

        while True:
            value = await self._write_to_iterator_queue.get()
            if isinstance(value, _FinishIteratorSentinel):
                break
            yield value

    async def _write_to_iterator_queue_interruptible(
        self,
        request: Union[RequestType, _FinishIteratorSentinel],
        call: _base_call.Call,
    ) -> None:
        if self._write_to_iterator_queue is None:
            raise cygrpc.UsageError(_API_STYLE_ERROR)

        # Write the specified 'request' to the request iterator queue using the
        # specified 'call' to allow for interruption of the write in the case
        # of abrupt termination of the call.
        if self._status_code_task is None:
            self._status_code_task = self._loop.create_task(call.code())

        put_task = self._loop.create_task(
            self._write_to_iterator_queue.put(request)
        )
        try:
            await asyncio.wait(
                (
                    put_task,
                    self._status_code_task,
                ),
                return_when=asyncio.FIRST_COMPLETED,
            )
        finally:
            # If put_task is not done, it means the RPC has completed.
            # This means the RPC terminated before the message could
            # be queued. We must cancel put_task to prevent a leak.
            if not put_task.done():
                put_task.cancel()

    async def write(self, request: RequestType) -> None:
        # If no queue was created it means that requests
        # should be expected through an iterators provided
        # by the caller.
        if self._write_to_iterator_queue is None:
            raise cygrpc.UsageError(_API_STYLE_ERROR)

        try:
            call = await self._interceptors_task
        except (asyncio.CancelledError, AioRpcError):
            raise asyncio.InvalidStateError(_RPC_ALREADY_FINISHED_DETAILS)

        if call.done():
            raise asyncio.InvalidStateError(_RPC_ALREADY_FINISHED_DETAILS)
        if call._done_writing_flag:
            raise asyncio.InvalidStateError(_RPC_HALF_CLOSED_DETAILS)

        await self._write_to_iterator_queue_interruptible(request, call)

        if call.done():
            raise asyncio.InvalidStateError(_RPC_ALREADY_FINISHED_DETAILS)

    async def done_writing(self) -> None:
        """Signal peer that client is done writing.

        This method is idempotent.
        """
        # If no queue was created it means that requests
        # should be expected through an iterators provided
        # by the caller.
        if self._write_to_iterator_queue is None:
            raise cygrpc.UsageError(_API_STYLE_ERROR)

        try:
            call = await self._interceptors_task
        except asyncio.CancelledError:
            raise asyncio.InvalidStateError(_RPC_ALREADY_FINISHED_DETAILS)

        await self._write_to_iterator_queue_interruptible(
            _FINISH_ITERATOR_SENTINEL, call
        )


def _resolve_registered_call_handle(
    channel: cygrpc.AioChannel,
    original_method: bytes,
    new_method: bytes,
    registered_call_handle: int,
) -> int:
    """Returns the registered call handle matching the outgoing method."""
    resolved_registered_call_handle = registered_call_handle
    if new_method != original_method and registered_call_handle != 0:
        resolved_registered_call_handle = channel.get_registered_call_handle(
            new_method,
        )
    return resolved_registered_call_handle


def _is_unary_unary_call(
    val: Union[
        _base_call.UnaryUnaryCall[RequestType, ResponseType], ResponseType
    ],
) -> TypeIs[_base_call.UnaryUnaryCall[RequestType, ResponseType]]:
    return isinstance(val, _base_call.UnaryUnaryCall)


class InterceptedUnaryUnaryCall(
    InterceptedCall,
    _InterceptedUnaryResponseMixin[ResponseType],
    _base_call.UnaryUnaryCall[RequestType, ResponseType],
):
    """Used for running a `UnaryUnaryCall` wrapped by interceptors.

    For the `__await__` method is it is proxied to the intercepted call only when
    the interceptor task is finished.
    """

    _loop: asyncio.AbstractEventLoop
    _channel: cygrpc.AioChannel

    def __init__(
        self,
        interceptors: Sequence[UnaryUnaryClientInterceptor],
        request: RequestType,
        timeout: Optional[float],
        metadata: Metadata,
        credentials: Optional[grpc.CallCredentials],
        wait_for_ready: Optional[bool],
        channel: cygrpc.AioChannel,
        method: bytes,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
        loop: asyncio.AbstractEventLoop,
        registered_call_handle: int = 0,
    ) -> None:
        self._loop = loop
        self._channel = channel
        self._registered_call_handle = registered_call_handle
        interceptors_task = loop.create_task(
            self._invoke(
                interceptors,
                method,
                timeout,
                metadata,
                credentials,
                wait_for_ready,
                request,
                request_serializer,
                response_deserializer,
            )
        )
        super().__init__(interceptors_task)

    async def _invoke(
        self,
        interceptors: Sequence[UnaryUnaryClientInterceptor],
        method: bytes,
        timeout: Optional[float],
        metadata: Optional[Metadata],
        credentials: Optional[grpc.CallCredentials],
        wait_for_ready: Optional[bool],
        request: RequestType,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
    ) -> Union[
        _base_call.UnaryUnaryCall[RequestType, ResponseType],
        UnaryUnaryCallResponse[RequestType, ResponseType],
    ]:
        """Run the RPC call wrapped in interceptors"""
        client_call_details = ClientCallDetails(
            method, timeout, metadata, credentials, wait_for_ready
        )
        return await self._run_interceptor(
            list(interceptors),
            method,
            request_serializer,
            response_deserializer,
            client_call_details,
            request,
        )

    async def _run_interceptor(
        self,
        interceptors: List[UnaryUnaryClientInterceptor],
        method: bytes,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
        client_call_details: ClientCallDetails,
        request: RequestType,
    ) -> Union[
        _base_call.UnaryUnaryCall[RequestType, ResponseType],
        UnaryUnaryCallResponse[RequestType, ResponseType],
    ]:
        if interceptors:
            continuation = functools.partial(
                self._run_interceptor,
                interceptors[1:],
                method,
                request_serializer,
                response_deserializer,
            )
            call_or_response = await interceptors[0].intercept_unary_unary(
                continuation, client_call_details, request
            )

            if _is_unary_unary_call(call_or_response):
                return call_or_response
            return UnaryUnaryCallResponse(call_or_response)

        registered_call_handle = _resolve_registered_call_handle(
            self._channel,
            method,
            client_call_details.method,
            self._registered_call_handle,
        )

        return UnaryUnaryCall(
            request,
            _timeout_to_deadline(client_call_details.timeout),
            client_call_details.metadata or Metadata(),
            client_call_details.credentials,
            client_call_details.wait_for_ready,
            self._channel,
            client_call_details.method,
            request_serializer,
            response_deserializer,
            self._loop,
            registered_call_handle,
        )

    def time_remaining(self) -> Optional[float]:
        raise NotImplementedError()


class InterceptedUnaryStreamCall(
    InterceptedCall,
    _InterceptedStreamResponseMixin[ResponseType],
    _base_call.UnaryStreamCall[RequestType, ResponseType],
):
    """Used for running a `UnaryStreamCall` wrapped by interceptors."""

    _loop: asyncio.AbstractEventLoop
    _channel: cygrpc.AioChannel
    _last_returned_call_from_interceptors: Optional[
        _base_call.UnaryStreamCall[RequestType, ResponseType]
    ]

    def __init__(
        self,
        interceptors: Sequence[UnaryStreamClientInterceptor],
        request: RequestType,
        timeout: Optional[float],
        metadata: Metadata,
        credentials: Optional[grpc.CallCredentials],
        wait_for_ready: Optional[bool],
        channel: cygrpc.AioChannel,
        method: bytes,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
        loop: asyncio.AbstractEventLoop,
        registered_call_handle: int = 0,
    ) -> None:
        self._loop = loop
        self._channel = channel
        self._registered_call_handle = registered_call_handle
        self._init_stream_response_mixin()
        self._last_returned_call_from_interceptors = None
        interceptors_task = loop.create_task(
            self._invoke(
                interceptors,
                method,
                timeout,
                metadata,
                credentials,
                wait_for_ready,
                request,
                request_serializer,
                response_deserializer,
            )
        )
        super().__init__(interceptors_task)

    async def _invoke(
        self,
        interceptors: Sequence[UnaryStreamClientInterceptor],
        method: bytes,
        timeout: Optional[float],
        metadata: Optional[Metadata],
        credentials: Optional[grpc.CallCredentials],
        wait_for_ready: Optional[bool],
        request: RequestType,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
    ) -> Union[
        _base_call.UnaryStreamCall[RequestType, ResponseType],
        UnaryStreamCallResponseIterator[RequestType, ResponseType],
    ]:
        """Run the RPC call wrapped in interceptors"""
        client_call_details = ClientCallDetails(
            method, timeout, metadata, credentials, wait_for_ready
        )
        return await self._run_interceptor(
            list(interceptors),
            method,
            request_serializer,
            response_deserializer,
            client_call_details,
            request,
        )

    async def _run_interceptor(
        self,
        interceptors: List[UnaryStreamClientInterceptor],
        method: bytes,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
        client_call_details: ClientCallDetails,
        request: RequestType,
    ) -> Union[
        _base_call.UnaryStreamCall[RequestType, ResponseType],
        UnaryStreamCallResponseIterator[RequestType, ResponseType],
    ]:
        if interceptors:
            continuation = functools.partial(
                self._run_interceptor,
                interceptors[1:],
                method,
                request_serializer,
                response_deserializer,
            )

            call_or_response_iterator = await interceptors[
                0
            ].intercept_unary_stream(continuation, client_call_details, request)

            if isinstance(
                call_or_response_iterator, _base_call.UnaryStreamCall
            ):
                self._last_returned_call_from_interceptors = (
                    call_or_response_iterator
                )
            else:
                last_call = self._last_returned_call_from_interceptors
                self._last_returned_call_from_interceptors = (
                    UnaryStreamCallResponseIterator[RequestType, ResponseType](
                        last_call,  # pyright: ignore[reportArgumentType]
                        call_or_response_iterator,
                    )
                )
            return self._last_returned_call_from_interceptors

        registered_call_handle = _resolve_registered_call_handle(
            self._channel,
            method,
            client_call_details.method,
            self._registered_call_handle,
        )

        self._last_returned_call_from_interceptors = UnaryStreamCall(
            request,
            _timeout_to_deadline(client_call_details.timeout),
            client_call_details.metadata or Metadata(),
            client_call_details.credentials,
            client_call_details.wait_for_ready,
            self._channel,
            client_call_details.method,
            request_serializer,
            response_deserializer,
            self._loop,
            registered_call_handle,
        )

        return self._last_returned_call_from_interceptors

    def time_remaining(self) -> Optional[float]:
        raise NotImplementedError()


class InterceptedStreamUnaryCall(  # pylint: disable=too-many-ancestors
    InterceptedCall,
    _InterceptedStreamRequestMixin[RequestType],
    _InterceptedUnaryResponseMixin[ResponseType],
    _base_call.StreamUnaryCall[RequestType, ResponseType],
):
    """Used for running a `StreamUnaryCall` wrapped by interceptors.

    For the `__await__` method is it is proxied to the intercepted call only when
    the interceptor task is finished.
    """

    _loop: asyncio.AbstractEventLoop
    _channel: cygrpc.AioChannel

    def __init__(
        self,
        interceptors: Sequence[StreamUnaryClientInterceptor],
        request_iterator: Optional[RequestIterableType[RequestType]],
        timeout: Optional[float],
        metadata: Metadata,
        credentials: Optional[grpc.CallCredentials],
        wait_for_ready: Optional[bool],
        channel: cygrpc.AioChannel,
        method: bytes,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
        loop: asyncio.AbstractEventLoop,
        registered_call_handle: int = 0,
    ) -> None:
        self._loop = loop
        self._channel = channel
        self._registered_call_handle = registered_call_handle
        request_iterator = self._init_stream_request_mixin(request_iterator)
        interceptors_task = loop.create_task(
            self._invoke(
                interceptors,
                method,
                timeout,
                metadata,
                credentials,
                wait_for_ready,
                request_iterator,
                request_serializer,
                response_deserializer,
            )
        )
        super().__init__(interceptors_task)

    async def _invoke(
        self,
        interceptors: Sequence[StreamUnaryClientInterceptor],
        method: bytes,
        timeout: Optional[float],
        metadata: Optional[Metadata],
        credentials: Optional[grpc.CallCredentials],
        wait_for_ready: Optional[bool],
        request_iterator: RequestIterableType[RequestType],
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
    ) -> _base_call.StreamUnaryCall[RequestType, ResponseType]:
        """Run the RPC call wrapped in interceptors"""
        client_call_details = ClientCallDetails(
            method, timeout, metadata, credentials, wait_for_ready
        )
        return await self._run_interceptor(
            list(interceptors),
            method,
            request_serializer,
            response_deserializer,
            client_call_details,
            request_iterator,
        )

    async def _run_interceptor(
        self,
        interceptors: Sequence[StreamUnaryClientInterceptor],
        method: bytes,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
        client_call_details: ClientCallDetails,
        request_iterator: RequestIterableType[RequestType],
    ) -> _base_call.StreamUnaryCall[RequestType, ResponseType]:
        if interceptors:
            continuation = functools.partial(
                self._run_interceptor,
                interceptors[1:],
                method,
                request_serializer,
                response_deserializer,
            )

            return await interceptors[0].intercept_stream_unary(
                continuation, client_call_details, request_iterator
            )

        registered_call_handle = _resolve_registered_call_handle(
            self._channel,
            method,
            client_call_details.method,
            self._registered_call_handle,
        )

        return StreamUnaryCall(
            request_iterator,
            _timeout_to_deadline(client_call_details.timeout),
            client_call_details.metadata or Metadata(),
            client_call_details.credentials,
            client_call_details.wait_for_ready,
            self._channel,
            client_call_details.method,
            request_serializer,
            response_deserializer,
            self._loop,
            registered_call_handle,
        )

    def time_remaining(self) -> Optional[float]:
        raise NotImplementedError()


class InterceptedStreamStreamCall(  # pylint: disable=too-many-ancestors
    InterceptedCall,
    _InterceptedStreamRequestMixin[RequestType],
    _InterceptedStreamResponseMixin[ResponseType],
    _base_call.StreamStreamCall[RequestType, ResponseType],
):
    """Used for running a `StreamStreamCall` wrapped by interceptors."""

    _loop: asyncio.AbstractEventLoop
    _channel: cygrpc.AioChannel
    _last_returned_call_from_interceptors: Optional[
        _base_call.StreamStreamCall[RequestType, ResponseType]
    ]

    def __init__(
        self,
        interceptors: Sequence[StreamStreamClientInterceptor],
        request_iterator: Optional[RequestIterableType[RequestType]],
        timeout: Optional[float],
        metadata: Metadata,
        credentials: Optional[grpc.CallCredentials],
        wait_for_ready: Optional[bool],
        channel: cygrpc.AioChannel,
        method: bytes,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
        loop: asyncio.AbstractEventLoop,
        registered_call_handle: int = 0,
    ) -> None:
        self._loop = loop
        self._channel = channel
        self._registered_call_handle = registered_call_handle
        self._init_stream_response_mixin()
        request_iterator = self._init_stream_request_mixin(request_iterator)
        self._last_returned_call_from_interceptors = None
        interceptors_task = loop.create_task(
            self._invoke(
                interceptors,
                method,
                timeout,
                metadata,
                credentials,
                wait_for_ready,
                request_iterator,
                request_serializer,
                response_deserializer,
            )
        )
        super().__init__(interceptors_task)

    async def _invoke(
        self,
        interceptors: Sequence[StreamStreamClientInterceptor],
        method: bytes,
        timeout: Optional[float],
        metadata: Optional[Metadata],
        credentials: Optional[grpc.CallCredentials],
        wait_for_ready: Optional[bool],
        request_iterator: RequestIterableType[RequestType],
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
    ) -> Union[
        _base_call.StreamStreamCall[RequestType, ResponseType],
        StreamStreamCallResponseIterator[RequestType, ResponseType],
    ]:
        """Run the RPC call wrapped in interceptors"""
        client_call_details = ClientCallDetails(
            method, timeout, metadata, credentials, wait_for_ready
        )
        return await self._run_interceptor(
            list(interceptors),
            method,
            request_serializer,
            response_deserializer,
            client_call_details,
            request_iterator,
        )

    async def _run_interceptor(
        self,
        interceptors: List[StreamStreamClientInterceptor],
        method: bytes,
        request_serializer: Optional[SerializingFunction[RequestType]],
        response_deserializer: Optional[DeserializingFunction[ResponseType]],
        client_call_details: ClientCallDetails,
        request_iterator: RequestIterableType[RequestType],
    ) -> Union[
        _base_call.StreamStreamCall[RequestType, ResponseType],
        StreamStreamCallResponseIterator[RequestType, ResponseType],
    ]:
        if interceptors:
            continuation = functools.partial(
                self._run_interceptor,
                interceptors[1:],
                method,
                request_serializer,
                response_deserializer,
            )

            call_or_response_iterator = await interceptors[
                0
            ].intercept_stream_stream(
                continuation, client_call_details, request_iterator
            )

            if isinstance(
                call_or_response_iterator, _base_call.StreamStreamCall
            ):
                self._last_returned_call_from_interceptors = (
                    call_or_response_iterator
                )
            else:
                last_call = self._last_returned_call_from_interceptors
                self._last_returned_call_from_interceptors = (
                    StreamStreamCallResponseIterator[RequestType, ResponseType](
                        last_call,  # pyright: ignore[reportArgumentType]
                        call_or_response_iterator,
                    )
                )
            return self._last_returned_call_from_interceptors

        registered_call_handle = _resolve_registered_call_handle(
            self._channel,
            method,
            client_call_details.method,
            self._registered_call_handle,
        )

        self._last_returned_call_from_interceptors = StreamStreamCall(
            request_iterator,
            _timeout_to_deadline(client_call_details.timeout),
            client_call_details.metadata or Metadata(),
            client_call_details.credentials,
            client_call_details.wait_for_ready,
            self._channel,
            client_call_details.method,
            request_serializer,
            response_deserializer,
            self._loop,
            registered_call_handle,
        )
        return self._last_returned_call_from_interceptors

    def time_remaining(self) -> Optional[float]:
        raise NotImplementedError()


class UnaryUnaryCallResponse(
    _base_call.UnaryUnaryCall[RequestType, ResponseType],
):
    """Final UnaryUnaryCall class finished with a response."""

    _response: ResponseType

    def __init__(self, response: ResponseType) -> None:
        self._response = response

    def cancel(self) -> bool:
        return False

    def cancelled(self) -> bool:
        return False

    def done(self) -> bool:
        return True

    def add_done_callback(self, callback: DoneCallbackType) -> None:
        raise NotImplementedError()

    def time_remaining(self) -> Optional[float]:
        raise NotImplementedError()

    async def initial_metadata(self) -> Metadata:
        return Metadata()

    async def trailing_metadata(self) -> Metadata:
        return Metadata()

    async def code(self) -> grpc.StatusCode:
        return grpc.StatusCode.OK

    async def details(self) -> str:
        return ""

    async def debug_error_string(self) -> Optional[str]:
        return None

    def __await__(self) -> Generator[Any, None, ResponseType]:
        if False:  # pylint: disable=using-constant-test
            # This code path is never used, but a yield statement is needed
            # for telling the interpreter that __await__ is a generator.
            yield None
        return self._response

    async def wait_for_connection(self) -> None:
        pass


class _StreamCallResponseIterator(Generic[RequestType, ResponseType]):
    _call: Union[
        _base_call.UnaryStreamCall[RequestType, ResponseType],
        _base_call.StreamStreamCall[RequestType, ResponseType],
    ]
    _response_iterator: AsyncIterable[ResponseType]

    def __init__(
        self,
        call: Union[
            _base_call.UnaryStreamCall[RequestType, ResponseType],
            _base_call.StreamStreamCall[RequestType, ResponseType],
        ],
        response_iterator: AsyncIterable[ResponseType],
    ) -> None:
        self._response_iterator = response_iterator
        self._call = call

    def cancel(self) -> bool:
        return self._call.cancel()

    def cancelled(self) -> bool:
        return self._call.cancelled()

    def done(self) -> bool:
        return self._call.done()

    def add_done_callback(self, callback: DoneCallbackType) -> None:
        self._call.add_done_callback(callback)

    def time_remaining(self) -> Optional[float]:
        return self._call.time_remaining()

    async def initial_metadata(self) -> Metadata:
        return await self._call.initial_metadata()

    async def trailing_metadata(self) -> Metadata:
        return await self._call.trailing_metadata()

    async def code(self) -> grpc.StatusCode:
        return await self._call.code()

    async def details(self) -> str:
        return await self._call.details()

    async def debug_error_string(self) -> Optional[str]:
        # debug_error_string is implemented on concrete calls but not yet
        # declared on _base_call.Call. We suppress pyright[reportAttributeAccessIssue]
        # to avoid public API changes for now.
        return await self._call.debug_error_string()  # type: ignore[reportAttributeAccessIssue]

    def __aiter__(self):
        return self._response_iterator.__aiter__()

    async def wait_for_connection(self) -> None:
        return await self._call.wait_for_connection()


class UnaryStreamCallResponseIterator(
    _StreamCallResponseIterator[RequestType, ResponseType],
    _base_call.UnaryStreamCall[RequestType, ResponseType],
):
    """UnaryStreamCall class which uses an alternative response iterator."""

    async def read(self) -> Union[EOFType, ResponseType]:
        # Behind the scenes everything goes through the
        # async iterator. So this path should not be reached.
        raise NotImplementedError()


class StreamStreamCallResponseIterator(
    _StreamCallResponseIterator[RequestType, ResponseType],
    _base_call.StreamStreamCall[RequestType, ResponseType],
):
    """StreamStreamCall class which uses an alternative response iterator."""

    async def read(self) -> Union[EOFType, ResponseType]:
        # Behind the scenes everything goes through the
        # async iterator. So this path should not be reached.
        raise NotImplementedError()

    async def write(self, request: RequestType) -> None:
        # Behind the scenes everything goes through the
        # async iterator provided by the InterceptedStreamStreamCall.
        # So this path should not be reached.
        raise NotImplementedError()

    async def done_writing(self) -> None:
        # Behind the scenes everything goes through the
        # async iterator provided by the InterceptedStreamStreamCall.
        # So this path should not be reached.
        raise NotImplementedError()

    @property
    def _done_writing_flag(self) -> bool:
        if not isinstance(
            self._call,
            (StreamStreamCall, StreamStreamCallResponseIterator),
        ):
            err_msg = "Should not happen: expected client-streaming call"
            raise TypeError(err_msg)
        return self._call._done_writing_flag
